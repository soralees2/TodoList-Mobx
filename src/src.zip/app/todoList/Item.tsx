/* eslint-disable jsx-a11y/no-static-element-interactions */
/* eslint-disable jsx-a11y/click-events-have-key-events */
import { observer } from 'mobx-react';
import React from 'react';
import TodoListStore from '../service/store/TodoListStore';

interface Props {
    index: number,
}

@observer
class Item extends React.Component<Props> {
    checkItem = () => {
      const { index } = this.props;
      const { itemList } = TodoListStore;

      itemList[index].checked = !itemList[index].checked;
    }

    delete = () => {
      // this.props.deleteItem(this.props.index);
      TodoListStore.deleteItem(this.props.index);
    }

    render() {
      const { index } = this.props;
      const { itemList } = TodoListStore;

      return (
        <>
          <div className="item">
            <div
              className={ itemList[index].checked ? 'float_left checked' : 'float_left' }
              onClick={ this.checkItem }
            >
              { itemList[index].title }
            </div>
            <div className="float_right" onClick={ this.delete }>X</div>
          </div>
        </>
      );
    }
}

export default Item;
